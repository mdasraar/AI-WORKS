a = int(input("Enter the height of binary tree : "))
tr = [[] for _ in range(a)]
le_tr = [[] for _ in range(a-1)]
ri_tr = [[] for _ in range(a-1)]
check = True

for i in range(a):
    no_of_inputs = pow(2,i)
    for j in range(no_of_inputs):
        val = int(input("Enter node data in level {} :".format(i+1)))
        tr[i].append(val)
        if i>0:
            if j < no_of_inputs//2:
                le_tr[i-1].append(val)
            else:
                ri_tr[i-1].append(val)
    if le_tr[i-1] != ri_tr[i-1]:
        check = False
       
print(tr)
print(le_tr)
print(ri_tr)
print(check)
