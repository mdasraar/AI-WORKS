substring(Sub, Str) :-
    sub_string(Str, _, _, _, Sub).

string_position(Sub, Str, Position) :-
    sub_string(Str, Position, _, _, Sub).

palindrome(X) :-
    reverse(X, X).

?- substring("cat", "concatenation").
% This will return true.

?- string_position("cat", "concatenation", Position).
% This will return Position = 4.

?- palindrome("radar").
% This will return true.
