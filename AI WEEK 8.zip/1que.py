
filename = "input.txt"  

try:
    with open(filename, 'r', encoding='utf-8') as file:
        char_count = 0
        num_count = 0
        word_count = 0
        in_word = False  

        for line in file:
            for char in line:
                char_count += 1

                if char.isdigit():
                    num_count += 1

                if char.isspace() or char in [',', '.', '!', '?', ':', ';']:
                    in_word = False
                elif not in_word:
                    word_count += 1
                    in_word = True

    print(f"Number of characters: {char_count}")
    print(f"Number of numbers: {num_count}")
    print(f"Number of words: {word_count}")

except FileNotFoundError:
    print("Error: Unable to open the file")

